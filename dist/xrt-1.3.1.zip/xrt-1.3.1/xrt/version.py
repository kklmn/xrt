﻿# -*- coding: utf-8 -*-
__versioninfo__ = (1, 3, 1)
__version__ = '.'.join(map(str, __versioninfo__))
__date__ = "24 May 2018"
