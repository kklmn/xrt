﻿# -*- coding: utf-8 -*-
__versioninfo__ = (1, 3, 4)
__version__ = '.'.join(map(str, __versioninfo__))
__date__ = "11 Mar 2019"
