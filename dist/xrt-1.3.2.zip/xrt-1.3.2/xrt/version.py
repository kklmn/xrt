﻿# -*- coding: utf-8 -*-
__versioninfo__ = (1, 3, 2)
__version__ = '.'.join(map(str, __versioninfo__))
__date__ = "7 Jun 2018"
