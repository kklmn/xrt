﻿# -*- coding: utf-8 -*-
__author__ = "Konstantin Klementiev, Roman Chernikov"
__date__ = "22 Jan 2016"
import numpy as np
import matplotlib.pyplot as plt
# path to xrt:
import sys
sys.path.append('c:\Ray-tracing')  # analysis:ignore
import xrt.backends.raycing.materials as rm

mSi = rm.Material('Si', rho=2.33)
mW = rm.Material('W', rho=19.3)
mL = rm.Multilayer(mSi, 27, mW, 18, 40, mSi)

E = np.logspace(1, 3, 501)
theta = np.radians(45)
rs, rp = mL.get_amplitude(E, np.sin(theta))[0:2]

plt.semilogx(E, abs(rs)**2, 'r', E, abs(rp)**2, 'b')
#plt.semilogx(E, abs(rs)**2/abs(rp)**2)
plt.gca().set_xlim(E[0], E[-1])
plt.show()
