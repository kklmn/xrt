﻿# -*- coding: utf-8 -*-
# path to xrt:
import os, sys; sys.path.append(os.path.join('..', '..', '..'))  # analysis:ignore
import numpy as np
import matplotlib.pyplot as plt
import xrt.backends.raycing.sources as rs
from xrt.backends.raycing.physconsts import EV2ERG

compareWithWS = True

energy = np.linspace(10, 90010, 901)
theta = np.linspace(-1, 1, 81) * 200e-6
psi = np.linspace(-1, 1, 21) * 50e-6
#Kmax, gmin = 8.99, 4.2
Kmax, gmin = 8.45, 4.5
#Ks = np.linspace(0.45, Kmax, 9)
Ks = np.logspace(np.log10(0.45), np.log10(Kmax), 9)

kw = dict(
    name='SoleilW50',
    nrays=1e5, period=50., n=39, eE=3., eI=0.5,
    eSigmaX=48.66, eSigmaZ=6.197, eEpsilonX=0.263*0, eEpsilonZ=0.008*0,
    eMin=energy[0], eMax=energy[-1], eN=len(energy)-1,
    xPrimeMax=theta[-1]*1e3, zPrimeMax=psi[-1]*1e3, nx=50, nz=50)


def power_vs_K_WS(Ks, kw):
    powers = []
    for iK, K in enumerate(Ks):
        print("K={0}, {1} of {2}".format(K, iK+1, len(Ks)))
        kw['K'] = K
        source = rs.WigglerWS(**kw)
        dtheta = source.xs[1] - source.xs[0]
        dpsi = source.zs[1] - source.zs[0]
        dE = source.Es[1] - source.Es[0]
        I0 = source.intensities_on_mesh()[0]
        I0 = np.concatenate((I0[:, :0:-1, :], I0), axis=1)
        I0 = np.concatenate((I0[:, :, :0:-1], I0), axis=2)
        power = I0.sum()*1e3 * dtheta * dpsi * dE * EV2ERG*1e-7  # [W]
        powers.append(power)
    return np.array(powers)


def main():
    if compareWithWS:
        powersWS = power_vs_K_WS(Ks, kw)

    kw['distE'] = 'BW'
    source = rs.Wiggler(**kw)
    powers = source.power_vs_K(energy, theta, psi, Ks)
    gaps = np.log(Kmax/Ks) / np.pi * source.L0 + gmin

    if compareWithWS:
        plt.plot(gaps, powersWS, 'o-', label='WS')
    plt.plot(gaps, powers, 'o-', label='xrt')
    ax = plt.gca()
    if compareWithWS:
        ax.legend(loc='upper right')
    ax.set_xlim([0, 55])
    ax.set_ylim([0, 1320])
    ax.set_xlabel(u'magnet gap (mm)')
    ax.set_ylabel(u'total power through 400×100 µrad² (W)')
    plt.gcf().suptitle(
        'Total beam power at Balder at 500 mA storage ring current',
        fontsize=13)

    maxPower = powers.max()
    iMax = len(Ks) - 1
    for i, (power, K, gap) in enumerate(zip(powers, Ks, gaps)):
        ax.text(gap, power + maxPower*0.03,
                '{0}{1:.2f}'.format('K=' if i == iMax else '', K), fontsize=9,
                ha='left', va='center', color='k')

    plt.savefig('wiggler_power_Balder.png')
    plt.show()

if __name__ == '__main__':
    main()
