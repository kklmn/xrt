# -*- coding: utf-8 -*-
__author__ = "Konstantin Klementiev", "Roman Chernikov"
__date__ = "10 Apr 2015"

import numpy as np
import matplotlib.pyplot as plt


def read_spectra_2D(fname, what='total'):
    x, z, I, l1, l3, l2 = np.loadtxt(fname, skiprows=10, usecols=range(6),
                                     unpack=True)
    if what == 's':
        I *= (1 + l1) / 2.
    elif what == 'p':
        I *= (1 - l1) / 2.
    elif what == 'circ':
        I *= (l2 + 1j*l3) / 2.

    size = int(I.size**0.5)
#    print(size)
    sh = [size, size]
    return (x.reshape(sh), z.reshape(sh), I.reshape(sh),
            l1.reshape(sh), l2.reshape(sh), l3.reshape(sh))


def intensity(ax, fXZ):
    x, z, I, l1, l2, l3 = fXZ
    ax.imshow(I, vmin=0., extent=[x.min(), x.max(), z.min(), z.max()],
              cmap='gray')


def show_spectra_2D(fXZ, saveName):
    fig = plt.figure(1, figsize=(3.2*1.5, 3.2))
    ax1 = fig.add_axes([0.03, 0.15, 0.8, 0.8], aspect='equal', label='1')
    ax1.set_xlabel(u'$x$ (mm)')
    ax1.set_ylabel(u'$z$ (mm)')
    x, z, I, l1, l2, l3 = fXZ
    ax1.set_xlim(x.min(), x.max())
    ax1.set_ylim(z.min(), z.max())
    intensity(ax1, fXZ)
    for axXY in (ax1.xaxis, ax1.yaxis):
        for line in axXY.get_ticklines():
            line.set_color('gray')

    fig.savefig('{0}.png'.format(saveName))
    plt.show()


if __name__ == '__main__':
#    fName = 'CoSAXS-05m-far'
#    fName = 'CoSAXS-05m-near'
#    fName = 'CoSAXS-25m-far'
#    fName = 'CoSAXS-25m-near'
    fName = 'spectra-custom'
    fXZ = read_spectra_2D(fName+'.dta', what='total')
    show_spectra_2D(fXZ, fName)
    fXZ = read_spectra_2D(fName+'.dta', what='s')
    show_spectra_2D(fXZ, fName+'_s')
#    fXZ = read_spectra_2D(fName+'.dta', what='p')
#    show_spectra_2D(fXZ, fName+'_p')
