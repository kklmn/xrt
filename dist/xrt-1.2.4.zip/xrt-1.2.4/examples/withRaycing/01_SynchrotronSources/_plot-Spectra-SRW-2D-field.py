# -*- coding: utf-8 -*-
__author__ = "Konstantin Klementiev", "Roman Chernikov"
__date__ = "10 Apr 2015"

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import pickle


def read_spectra_2D(fname):
    x, z, EsRe, EsIm, EpRe, EpIm = np.loadtxt(fname, skiprows=11, unpack=True)
    size = int(x.size**0.5)
    print(x.size, size)
    sh = [size, size]
    return (x.reshape(sh), z.reshape(sh), EsRe.reshape(sh),
            EsIm.reshape(sh), EpRe.reshape(sh), EpIm.reshape(sh))


def read_SRW_2D(fname):
    with open(fname, 'rb') as f:
        energy, x, z, Es, Ep = pickle.load(f)
    size = int(Es.size**0.5)
    print(Es.size, size)
    sh = [size, size]
    return (x, z, Es.real.reshape(sh), Es.imag.reshape(sh),
            Ep.real.reshape(sh), Ep.imag.reshape(sh))


def intensity_colored(ax, axC, fXZ, what):
    x, z = fXZ[0], fXZ[1]
    if 's' in what:
        fRe, fIm = fXZ[2], fXZ[3]
    else:
        fRe, fIm = fXZ[4], fXZ[5]
    shift = np.pi/6 * 5
    cosShift, sinShift = np.cos(shift), np.sin(shift)
    phase = np.arctan2(fRe*sinShift + fIm*cosShift,
                       fRe*cosShift - fIm*sinShift)
    I = fRe**2 + fIm**2
    plt.setp(axC.get_xticklabels(), visible=False)
    axC.yaxis.set_label_position("right")
    axC.yaxis.tick_right()
    axC.set_xlim([0, 1])
    axC.set_ylim([-np.pi, np.pi])
    axC.set_ylabel('E{0} phase'.format(what))
    axC.set_yticks([l*np.pi for l in (-1, -0.5, 0, 0.5, 1)])
    axC.set_yticklabels(
        (r'$-\pi$', r'-$\frac{\pi}{2}$', 0, r'$\frac{\pi}{2}$', r'$\pi$'))

    hue = np.array(phase)
    hue -= hue.min()
    hue /= hue.max()
    sat = np.ones_like(hue)
    val = I / I.max()
#    hsvI0 = np.stack((hue, sat, val), axis=3) # numpy1.10
    hsvI0 = np.zeros([d for d in hue.shape] + [3])
    hsvI0[:, :, 0] = hue
    hsvI0[:, :, 1] = sat
    hsvI0[:, :, 2] = val

    rgbI0 = mpl.colors.hsv_to_rgb(hsvI0)
    ax.imshow(rgbI0 / rgbI0.max(), extent=[x.min(), x.max(), z.min(), z.max()])

    hue = np.linspace(-np.pi, np.pi, 256)[:, np.newaxis]
    hue -= hue.min()
    hue /= hue.max()
    sat = np.ones_like(hue)
    val = np.ones_like(hue)
#    hsvC = np.stack((hue, sat, val), axis=2) # numpy1.10
    hsvC = np.zeros([d for d in hue.shape] + [3])
    hsvC[:, :, 0] = hue
    hsvC[:, :, 1] = sat
    hsvC[:, :, 2] = val
    rgbC = mpl.colors.hsv_to_rgb(hsvC)
    axC.imshow(rgbC / rgbC.max(), aspect='auto', origin='lower',
               extent=[0, 1, -np.pi, np.pi])


def show_2D(fXZ, saveName, what='s'):
    fig = plt.figure(1, figsize=(3.2*1.5, 3.2))
    ax1 = fig.add_axes([0.05, 0.15, 0.8, 0.8], aspect='equal', label='1')
    ax1.set_xlabel(u'$x$ (µm)')
    ax1.set_ylabel(u'$z$ (µm)')
    x, z, I, l1, l2, l3 = fXZ
    x *= 1e3
    z *= 1e3
    ax1.set_xlim(x.min(), x.max())
    ax1.set_ylim(z.min(), z.max())
    axC = fig.add_axes([0.75, 0.15, 0.02, 0.8], label='2')
    intensity_colored(ax1, axC, fXZ, what)
    for axXY in (ax1.xaxis, ax1.yaxis):
        for line in axXY.get_ticklines():
            line.set_color('gray')
    axC.set_xticks([])

    fig.savefig('{0}_{1}.png'.format(saveName, what))


if __name__ == '__main__':
#    fName = 'spectra-near5-0em-field'
#    fXZ = read_spectra_2D(fName+'.dta')

    fName = 'SRWres-0em-05m'
    fXZ = read_SRW_2D(fName+'.pickle')

#    show_2D(fXZ, fName, 's')
    show_2D(fXZ, fName, 'p')

    plt.show()
